import asyncio
import logging
import os
import re
import sqlite3
from datetime import datetime, timezone
from urllib.parse import urlparse

import feedparser
from dotenv import load_dotenv
from openai import OpenAI
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

load_dotenv()
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
OWNER_ID = os.getenv("OWNER_TELEGRAM_ID", "").strip()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5-mini").strip()
SCAN_MINUTES = max(5, int(os.getenv("SCAN_MINUTES", "15")))
DB_PATH = os.getenv("DB_PATH", "jobs.sqlite3")
FEEDS_FILE = os.getenv("FEEDS_FILE", "feeds.txt")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("freelance-ai")

KEYWORDS = [
    "product listing", "product images", "amazon listing", "ecommerce",
    "e-commerce", "product card", "product infographic", "listing design",
    "wildberries", "wildberries card", "ozon", "карточк", "инфографик",
    "дизайн товара", "оформление товара", "маркетплейс", "товарная карточка"
]

def db():
    con = sqlite3.connect(DB_PATH)
    con.execute("CREATE TABLE IF NOT EXISTS seen (key TEXT PRIMARY KEY, seen_at TEXT)")
    con.commit()
    return con

def is_owner(update: Update) -> bool:
    return bool(OWNER_ID) and update.effective_user and str(update.effective_user.id) == OWNER_ID

async def private(update: Update, text: str):
    if update.effective_chat:
        await update.effective_chat.send_message(text, disable_web_page_preview=True)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not OWNER_ID:
        await private(update, "Бот почти настроен. Узнай свой Telegram ID командой /myid, затем впиши его в OWNER_TELEGRAM_ID в файле .env и перезапусти бота.")
        return
    if not is_owner(update):
        await private(update, "Этот бот приватный.")
        return
    await private(update,
        "Привет, Лёха! 🤖 Я ищу заказы на оформление карточек товаров и присылаю подходящие объявления.\n\n"
        "Команды:\n/status — состояние бота\n/scan — проверить источники сейчас\n/sources — список RSS-источников\n/myid — твой Telegram ID\n\n"
        "Поиск идёт по подключённым RSS-лентам. Добавь ссылки в feeds.txt и перезапусти бота.")

async def myid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await private(update, f"Твой Telegram ID: {update.effective_user.id if update.effective_user else 'не определён'}")

async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update):
        await private(update, "Доступ закрыт. Сначала настрой OWNER_TELEGRAM_ID в .env.")
        return
    feeds = load_feeds()
    await private(update, f"🟢 Бот запущен\nИнтервал проверки: {SCAN_MINUTES} мин.\nRSS-источников: {len(feeds)}\nИИ: {'подключён' if OPENAI_API_KEY else 'не подключён (работает фильтр по ключевым словам)'}")

async def sources(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update):
        await private(update, "Доступ закрыт.")
        return
    feeds = load_feeds()
    await private(update, "Подключённые RSS-источники:\n" + ("\n".join(f"• {x}" for x in feeds) if feeds else "Пока нет. Добавь RSS-ссылки в feeds.txt."))

def load_feeds():
    p = Path(FEEDS_FILE)
    if not p.exists():
        return []
    return [line.strip() for line in p.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.strip().startswith("#") and urlparse(line.strip()).scheme in ("http", "https")]

def already_seen(key):
    with db() as con:
        cur = con.execute("SELECT 1 FROM seen WHERE key=?", (key,))
        return cur.fetchone() is not None

def mark_seen(key):
    with db() as con:
        con.execute("INSERT OR IGNORE INTO seen(key, seen_at) VALUES (?, ?)",
                    (key, datetime.now(timezone.utc).isoformat()))
        con.commit()

def ai_review(title, summary, link):
    if not OPENAI_API_KEY:
        text = (title + " " + summary).lower()
        return any(k in text for k in KEYWORDS), 0, "Совпадение по ключевым словам"
    try:
        client = OpenAI(api_key=OPENAI_API_KEY)
        response = client.responses.create(
            model=OPENAI_MODEL,
            input=(
                "Ты фильтр заказов для начинающего фрилансера, который делает дизайн и инфографику "
                "карточек товаров для маркетплейсов. Оцени только соответствие задачи. "
                "Не выдумывай бюджет или детали. Если это заказ на оформление карточек товара, "
                "изображения товара, инфографику или дизайн листинга — ответь MATCH; иначе SKIP. "
                "Формат строго: MATCH|число от 0 до 100|краткая причина ИЛИ SKIP.\n\n"
                f"Заголовок: {title}\nОписание: {summary[:4000]}\nСсылка: {link}"
            ),
        )
        result = response.output_text.strip()
        m = re.match(r"MATCH\|(\d{1,3})\|(.*)", result, re.I | re.S)
        if m:
            return True, min(100, int(m.group(1))), m.group(2).strip()[:300]
        return False, 0, "Не подходит по оценке ИИ"
    except Exception:
        log.exception("AI review failed; using keyword filter")
        text = (title + " " + summary).lower()
        return any(k in text for k in KEYWORDS), 0, "Совпадение по ключевым словам (ИИ временно недоступен)"

def scan():
    found = []
    for feed_url in load_feeds():
        try:
            parsed = feedparser.parse(feed_url)
            if parsed.bozo and not parsed.entries:
                log.warning("Feed error: %s", feed_url)
                continue
            for entry in parsed.entries[:50]:
                link = entry.get("link", "")
                title = entry.get("title", "Без названия")
                summary = re.sub(r"<[^>]+>", " ", entry.get("summary", "") or "")
                summary = re.sub(r"\s+", " ", summary).strip()
                key = entry.get("id") or link or (title + summary)
                if not key or already_seen(key):
                    continue
                # Mark every item to avoid repeatedly processing irrelevant posts.
                mark_seen(key)
                match, score, reason = ai_review(title, summary, link)
                if match:
                    found.append((title, summary, link, score, reason, feed_url))
        except Exception:
            log.exception("Could not read feed %s", feed_url)
    return found

async def run_scan(app: Application):
    if not OWNER_ID:
        log.warning("OWNER_TELEGRAM_ID is not set; scan notifications are disabled")
        return
    try:
        jobs = await asyncio.to_thread(scan)
        for title, summary, link, score, reason, source in jobs:
            text = (
                f"🆕 <b>Возможный заказ на карточки</b>\n\n"
                f"<b>{escape_html(title[:300])}</b>\n"
                f"{escape_html(summary[:900]) if summary else 'Описание не указано'}\n\n"
                f"🤖 Оценка соответствия: {score}/100\n"
                f"💡 {escape_html(reason)}\n"
                f"🔗 {escape_html(link)}\n"
                f"Источник: {escape_html(urlparse(source).netloc)}"
            )
            await app.bot.send_message(chat=int(OWNER_ID), text=text, parse_mode="HTML", disable_web_page_preview=True)
    except Exception:
        log.exception("Scan failed")

def escape_html(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")

async def scan_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update):
        await private(update, "Доступ закрыт.")
        return
    await private(update, "🔎 Проверяю подключённые источники…")
    await run_scan(context.application)
    await private(update, "Проверка завершена. Если подходящих новых объявлений нет, уведомления не отправлялись.")

async def post_init(app: Application):
    if OWNER_ID:
        app.job_queue.run_repeating(lambda ctx: run_scan(app), interval=SCAN_MINUTES * 60, first=5, name="job-search")

def main():
    if not BOT_TOKEN:
        raise SystemExit("Не задан TELEGRAM_BOT_TOKEN в .env")
    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("myid", myid))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("sources", sources))
    app.add_handler(CommandHandler("scan", scan_command))
    app.run_polling()

if __name__ == "__main__":
    main()